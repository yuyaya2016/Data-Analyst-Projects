
### Confidence Intervals - Part I

First let's read in the necessary libraries and the dataset.  You also have the full and reduced versions of the data available.  The reduced version is an example of you would actually get in practice, as it is the sample.  While the full data is an example of everyone in your population.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline

np.random.seed(42)

coffee_full = pd.read_csv('coffee_dataset.csv')
coffee_red = coffee_full.sample(200) #this is the only data you might actually get in the real world.
```


```python
coffee_red.head(3)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>age</th>
      <th>drinks_coffee</th>
      <th>height</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2402</th>
      <td>2874</td>
      <td>&lt;21</td>
      <td>True</td>
      <td>64.357154</td>
    </tr>
    <tr>
      <th>2864</th>
      <td>3670</td>
      <td>&gt;=21</td>
      <td>True</td>
      <td>66.859636</td>
    </tr>
    <tr>
      <th>2167</th>
      <td>7441</td>
      <td>&lt;21</td>
      <td>False</td>
      <td>66.659561</td>
    </tr>
  </tbody>
</table>
</div>



`1.` What is the proportion of coffee drinkers in the sample?  What is the proportion of individuals that don't drink coffee?


```python
#prop of drink coffee
coffee_red.drinks_coffee.mean()
```




    0.59499999999999997




```python
#prop of not drink coffee
1 - coffee_red.drinks_coffee.mean()
```




    0.40500000000000003



`2.` Of the individuals who drink coffee, what is the average height? Of the individuals who do not drink coffee, what is the average height?


```python
coffee_red.query("drinks_coffee == True").height.mean()
```




    68.119629908586163




```python
coffee_red.query("drinks_coffee == False").height.mean()
```




    66.784922799278775



`3.` Simulate 200 "new" individuals from your original sample of 200.  What are the proportion of coffee drinkers in your bootstrap sample?  How about individuals that don't drink coffee?


```python
#replace = True : sampling with replacement
bootstrap = coffee_red.sample(200, replace = True)
bootstrap.drinks_coffee.mean(), 1-bootstrap.drinks_coffee.mean()
```




    (0.65000000000000002, 0.34999999999999998)



`4.` Now simulate your bootstrap sample 10,000 times and take the mean height of the non-coffee drinkers in each sample. Each bootstrap sample should be from the very first sample of 200 data points. Plot the distribution, and pull the values necessary for a 95% confidence interval.  What do you notice about the sampling distribution of the mean in this example?


```python
bootstrap_2 = []
for _ in range(10000):
    bootstrap = coffee_red.sample(200, replace = True)
    bootstrap_2.append(bootstrap.query("drinks_coffee == False").height.mean())
    
bootstrap_2 = np.array(bootstrap_2)    
```


```python
plt.hist(bootstrap_2)
```




    (array([   16.,   107.,   578.,  1606.,  2649.,  2740.,  1600.,   579.,
              110.,    15.]),
     array([ 65.27657893,  65.57718387,  65.87778881,  66.17839375,
             66.47899869,  66.77960363,  67.08020857,  67.38081351,
             67.68141845,  67.98202339,  68.28262833]),
     <a list of 10 Patch objects>)




![png](output_13_1.png)



```python
np.percentile(bootstrap_2, 2.5), np.percentile(bootstrap_2, 97.5)
```




    (65.982314686704754, 67.573643979538318)



`5.`  Did your interval capture the actual average height of non-coffee drinkers in the population?  Look at the average in the population and the two bounds provided by your 95% confidence interval, and then answer the final quiz question below.


```python
coffee_red.query("drinks_coffee == False").height.mean()
```




    66.784922799278775


